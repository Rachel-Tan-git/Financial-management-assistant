Project name:
Financial-management-assistant

Squad members: 
Name: Chenchen Tan 
SID: 219083208 
Name: Xinghao Li 
SID: 219082892

Overview:
This is an app about data storage called financial management assistant, which can help users quickly and carefully record every expense and check the daily income and expenditure. The app also has features that make it easier for users to use, including the ability to search, generate histograms, print PDF files, send feedback, and send/receive notifications. 

GitHub link:
https://github.com/Rachel-Tan-git/Financial-management-assistant.git